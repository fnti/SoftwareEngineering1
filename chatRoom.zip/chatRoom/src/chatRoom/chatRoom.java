package chatRoom;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class chatRoom {
	/**
	 * @param args
	 */
         
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
	     My my=new My();
	     my.setVisible(true);
	     
           
	}

	
}
class My  extends JFrame implements ActionListener 
{
    JTextArea receiver; // ��ʾ�Ի����ݵ��ı���
    JTextField sender; // ���뷢�����ݵ��ı���  
    My()
    {
	 this.setTitle("����������  ");
	 this.setSize(600, 400);
	 this.setLocation(300, 240);
	 this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         receiver = new JTextArea();
         receiver.setBackground(Color.green);
         receiver.setEditable(false); 
	 this.add(receiver);
	 sender = new JTextField(25);
	 this.add(sender,"South");
	 sender.addActionListener(this); // ע�ᵥ���¼�������
     }
     public void actionPerformed(ActionEvent e) 
     {
	  if (e.getSource() == sender) 
	  {
		this.process();
		
	  }
	  if (e.getActionCommand().equals("Bye")|| e.getActionCommand().equals("bye"))
	  {
		System.exit(0);
	  }
     }
     public void process()
     {
	   PipedInputStream inStream;
	   PipedOutputStream outStream;
	   PrintStream printOut;
	   try
	   { 
		outStream = new PipedOutputStream();
		inStream = new PipedInputStream(outStream);
		new Writer(outStream).start();
		new Reader( inStream ).start(); 
	   }catch(IOException e){ } 
    }
     class Reader extends Thread
     {
     	private PipedInputStream inStream;//���ж�����
     	public Reader(PipedInputStream i){
     		inStream = i;
     	}
     	public void run(){
     		String line;
     		DataInputStream d;
     		boolean reading = true;
     		try{
     			d = new DataInputStream( inStream );
     			while( reading && d != null){
     				try{
     					line = d.readLine();
     					if( line != null ){
     					    receiver.append(line + "\n");
     					    sender.setText("");
     					    receiver.setCaretPosition(receiver.getDocument().getLength());
     					}
     					else
     						reading = false;
     				}catch(IOException e){
     					throw e; 
     				}
     			}
     		}catch(IOException e){
     			System.exit(0);
     		}
     		try{
     			Thread.sleep( 4000 );
     		}catch(InterruptedException e ){}
     	}
     }
     class Writer extends Thread{
     	private PipedOutputStream outStream;//���������
     	public Writer(PipedOutputStream o){ 
     		outStream = o;
     	} 
     	public void run(){
     		PrintStream p = new PrintStream( outStream );
     		p.println(sender.getText());
     		p.close(); 
     		p = null;
     	}
     }
}
